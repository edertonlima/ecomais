<?php get_header(); 
	get_template_part( 'content-none', 'page' );
get_footer(); ?>

